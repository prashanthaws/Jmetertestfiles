/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.94, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.8333333333333334, 500, 1500, "/actions/Account.action-464"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Catalog.action-462"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Account.action-465"], "isController": false}, {"data": [0.6666666666666666, 500, 1500, "UserReg_T04_EnterAndSaveAccInfo"], "isController": true}, {"data": [1.0, 500, 1500, "/actions/Account.action-461-0"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Account.action-460"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Account.action-461"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Account.action-461-1"], "isController": false}, {"data": [1.0, 500, 1500, "UserReg_T02_ClkSignIn"], "isController": true}, {"data": [0.8333333333333334, 500, 1500, "UserReg_T01_PetstoreHomepage"], "isController": true}, {"data": [0.8333333333333334, 500, 1500, "UserReg_T07_SignOut"], "isController": true}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.8333333333333334, 500, 1500, "UserReg_T05_SignIn"], "isController": true}, {"data": [1.0, 500, 1500, "UserReg_T03_RegisterNow"], "isController": true}, {"data": [1.0, 500, 1500, "/actions/Account.action-465-0"], "isController": false}, {"data": [0.8333333333333334, 500, 1500, "/actions/Catalog.action-456"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Account.action-465-1"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Catalog.action-469"], "isController": false}, {"data": [0.6666666666666666, 500, 1500, "UserReg_T06_Login"], "isController": true}, {"data": [1.0, 500, 1500, "/actions/Account.action-468-1"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Account.action-468"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Account.action-468-0"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Account.action-458"], "isController": false}, {"data": [1.0, 500, 1500, "/actions/Catalog.action-466"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 54, 0, 0.0, 210.33333333333331, 0, 607, 189.0, 396.0, 494.25, 607.0, 0.49019162861629795, 0.7649758790542932, 0.41644480862101835], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["/actions/Account.action-464", 3, 0, 0.0, 339.3333333333333, 162, 603, 253.0, 603.0, 603.0, 603.0, 0.03781242516290853, 0.07221533152043762, 0.02503596119184764], "isController": false}, {"data": ["/actions/Catalog.action-462", 3, 0, 0.0, 179.33333333333334, 143, 199, 196.0, 199.0, 199.0, 199.0, 0.04024792723174756, 0.07667020513026913, 0.026805748410206876], "isController": false}, {"data": ["/actions/Account.action-465", 3, 0, 0.0, 396.3333333333333, 321, 458, 410.0, 458.0, 458.0, 458.0, 0.03842114699930842, 0.08500928911272765, 0.06753717245972184], "isController": false}, {"data": ["UserReg_T04_EnterAndSaveAccInfo", 3, 0, 0.0, 537.3333333333334, 433, 611, 568.0, 611.0, 611.0, 611.0, 0.04009676686403186, 0.16190113807989948, 0.11899811962870394], "isController": true}, {"data": ["/actions/Account.action-461-0", 3, 0, 0.0, 189.0, 148, 221, 198.0, 221.0, 221.0, 221.0, 0.04028359651949726, 0.009048073436996457, 0.062431706715275544], "isController": false}, {"data": ["/actions/Account.action-460", 3, 0, 0.0, 230.0, 150, 337, 203.0, 337.0, 337.0, 337.0, 0.04140101018464851, 0.10091496232508072, 0.028058887761861388], "isController": false}, {"data": ["/actions/Account.action-461", 3, 0, 0.0, 358.0, 290, 415, 369.0, 415.0, 415.0, 415.0, 0.04020369874028411, 0.08574695121951219, 0.09253917766684534], "isController": false}, {"data": ["/actions/Account.action-461-1", 3, 0, 0.0, 168.66666666666666, 142, 216, 148.0, 216.0, 216.0, 216.0, 0.04028359651949726, 0.0768692847647438, 0.030291376289075092], "isController": false}, {"data": ["UserReg_T02_ClkSignIn", 3, 0, 0.0, 191.33333333333334, 143, 243, 188.0, 243.0, 243.0, 243.0, 0.04128648693282689, 0.07855452998775168, 0.029110198794434584], "isController": true}, {"data": ["UserReg_T01_PetstoreHomepage", 3, 0, 0.0, 333.0, 188, 607, 204.0, 607.0, 607.0, 607.0, 0.041484595386912994, 0.10272568916284086, 0.021998178999114996], "isController": true}, {"data": ["UserReg_T07_SignOut", 3, 0, 0.0, 485.6666666666667, 462, 525, 470.0, 525.0, 525.0, 525.0, 0.038744172230760286, 0.15930261700740014, 0.0759370641280624], "isController": true}, {"data": ["Debug Sampler", 6, 0, 0.0, 0.33333333333333337, 0, 1, 0.0, 1.0, 1.0, 1.0, 0.0739125614398167, 0.0339608009349939, 0.0], "isController": false}, {"data": ["UserReg_T05_SignIn", 3, 0, 0.0, 339.3333333333333, 162, 603, 253.0, 603.0, 603.0, 603.0, 0.03781290176208122, 0.07221624174418312, 0.025036276752627998], "isController": true}, {"data": ["UserReg_T03_RegisterNow", 3, 0, 0.0, 230.33333333333334, 150, 338, 203.0, 338.0, 338.0, 338.0, 0.041401581540414845, 0.12010771311464098, 0.028059274989304592], "isController": true}, {"data": ["/actions/Account.action-465-0", 3, 0, 0.0, 234.33333333333334, 175, 268, 260.0, 268.0, 268.0, 268.0, 0.03851486673856109, 0.008650800146356495, 0.038890988484054846], "isController": false}, {"data": ["/actions/Catalog.action-456", 3, 0, 0.0, 332.6666666666667, 188, 607, 203.0, 607.0, 607.0, 607.0, 0.04148516905206388, 0.08383461245937911, 0.021998483198506533], "isController": false}, {"data": ["/actions/Account.action-465-1", 3, 0, 0.0, 161.66666666666666, 145, 190, 150.0, 190.0, 190.0, 190.0, 0.038549510421217646, 0.07663472009842975, 0.028836840803371795], "isController": false}, {"data": ["/actions/Catalog.action-469", 3, 0, 0.0, 154.0, 143, 166, 153.0, 166.0, 166.0, 166.0, 0.038936766690893986, 0.07426123569073824, 0.02532410802356972], "isController": false}, {"data": ["UserReg_T06_Login", 3, 0, 0.0, 583.6666666666666, 482, 659, 610.0, 659.0, 659.0, 659.0, 0.03832249658291072, 0.16099939482390813, 0.0927374477855984], "isController": true}, {"data": ["/actions/Account.action-468-1", 3, 0, 0.0, 151.33333333333334, 142, 161, 151.0, 161.0, 161.0, 161.0, 0.03894232641458, 0.07709870743928242, 0.0253277240157327], "isController": false}, {"data": ["/actions/Account.action-468", 3, 0, 0.0, 331.6666666666667, 304, 382, 309.0, 382.0, 382.0, 382.0, 0.038821382817655965, 0.08557890769569212, 0.05083933042819985], "isController": false}, {"data": ["/actions/Account.action-468-0", 3, 0, 0.0, 180.33333333333334, 143, 240, 158.0, 240.0, 240.0, 240.0, 0.03889738868863937, 0.008736718162487358, 0.02564036852034333], "isController": false}, {"data": ["/actions/Account.action-458", 3, 0, 0.0, 191.33333333333334, 143, 243, 188.0, 243.0, 243.0, 243.0, 0.04128648693282689, 0.07855452998775168, 0.029110198794434584], "isController": false}, {"data": ["/actions/Catalog.action-466", 3, 0, 0.0, 187.33333333333334, 161, 201, 200.0, 201.0, 201.0, 201.0, 0.038524263865524634, 0.0766096119643522, 0.0255072762703376], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 54, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
